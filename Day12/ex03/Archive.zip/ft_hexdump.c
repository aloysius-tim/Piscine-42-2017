/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkeynes <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/15 23:43:20 by tkeynes           #+#    #+#             */
/*   Updated: 2017/08/17 05:38:35 by tkeynes          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_hexdump.h"

int		ft_open_fd(int *fd, char **argv, int ac)
{
	if ((*fd = open(argv[(ac)], O_RDONLY, S_IREAD)) == -1)
	{
		write(2, "\nhexdump: ", 10);
		write(2, argv[ac], ft_strlen(argv[ac]));
		write(2, ": No such file or directory\n", 28);
		return (0);
	}
	return (1);
}

int		ft_hexdump_bis(int fd, int *ac, int *ret_read2, char **argv, int argc)
{
	int new_fd;

	while (*ret_read2 != 16 && *ac + 1 < argc)
	{
		close(fd);
		(*ac)++;
		if (ft_open_fd(&new_fd, argv, *ac) == 0)
			return (new_fd);
		*ret_read2 += read(new_fd, g_buffer2, 16 - *ret_read2);
		g_buffer2[*ret_read2] = '\0';
		ft_strcat(g_buffer, g_buffer2);
	}
	return (new_fd);
}

void	ft_hexdump(char **argv, int fd, int argc, int ret_read, int ret_read2)
{
	int		counter;
	int		ac;

	counter = 0;
	ac = 2;
	if (ft_open_fd(&fd, argv, ac) == 0)
		return ;
	while ((ret_read != 0 || ret_read2 != 0) && ac  < argc)
	{
		ret_read2 = 0;
		print_hexa(counter, 8);
		ret_read = read(fd, g_buffer, 16);
		g_buffer[ret_read] = '\0';
		ret_read2 = ret_read;
		if (ret_read2 != 16 && ac + 1 < argc)
			fd = ft_hexdump_bis(fd, &ac, &ret_read2, argv, argc);
		if (fd < 0)
			return ;
		ft_print_spaces(g_buffer);
		ft_print_c_format_bis(g_buffer);
		ft_print_data(g_buffer, g_buffer2);
		counter += ft_strlen(g_buffer);
	}
	close(fd);
}
