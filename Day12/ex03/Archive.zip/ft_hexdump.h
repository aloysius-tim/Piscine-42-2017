/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkeynes <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/15 23:43:31 by tkeynes           #+#    #+#             */
/*   Updated: 2017/08/17 05:37:22 by tkeynes          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEXDUMP_H
# define FT_HEXDUMP_H
# include "ft_nbr_str_base.h"
# include "ft_print.h"
# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>

char	*g_buffer;
char	*g_buffer2;
void	ft_hexdump(char **argv, int fd, int argc, int ret_read, int ret_read2);
char	*ft_nbr_str_base(unsigned int nbr, int base);
int		ft_strlen(char *str);
char	*ft_strcat(char *dest, char *src);
#endif
