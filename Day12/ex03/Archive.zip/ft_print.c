/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkeynes <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/17 05:23:36 by tkeynes           #+#    #+#             */
/*   Updated: 2017/08/17 05:30:42 by tkeynes          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_print.h"

void	ft_put_str_escape(char *data)
{
	while (*data)
	{
		if (*data == '\n' || *data == '\a' || *data == '\b' || *data == '\f' ||
				*data == '\r' || *data == '\t' || *data == '\v')
			write(1, ".", 1);
		else
			write(1, data, 1);
		data++;
	}
}

void	ft_print_c_format(int counter_str, int ret_read, char *buffer)
{
	counter_str--;
	if (counter_str < ret_read)
		print_hexa(buffer[counter_str], 2);
	else
		write(1, "  ", 2);
	if (counter_str == 7)
		write(1, "  ", 2);
	else
		write(1, " ", 1);
}

void	ft_print_c_format_bis(char *buffer)
{
	int counter;

	counter = 0;
	if (ft_strlen(buffer) > 0)
	{
		while (*buffer)
		{
			print_hexa(*buffer, 2);
			if (counter == 7)
				write(1, "  ", 2);
			else
				write(1, " ", 1);
			buffer++;
			counter++;
		}
		while (counter < 16)
		{
			if (counter == 7)
				write(1, "     ", 4);
			else
				write(1, "   ", 3);
			counter++;
		}
	}
}

void	ft_print_spaces(char *buffer)
{
	if (ft_strlen(buffer) > 0)
		write(1, "  ", 2);
	else
		write(1, "\n", 1);
}

void	ft_print_data(char *buffer, char *buffer2)
{
	buffer2[0] = '\0';
	if (ft_strlen(buffer) > 0)
	{
		write(1, " |", 2);
		ft_put_str_escape(buffer);
		write(1, "|\n", 2);
	}
}
