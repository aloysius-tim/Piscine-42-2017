/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkeynes <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/17 05:24:14 by tkeynes           #+#    #+#             */
/*   Updated: 2017/08/17 05:32:45 by tkeynes          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINT_H
# define FT_PRINT_H
# include <unistd.h>
# include "ft_nbr_str_base.h"

void	ft_print_data(char *buffer, char *buffer2);
void	ft_print_spaces(char *buffer);
void	ft_print_c_format_bis(char *buffer);
void	ft_print_c_format(int counter_str, int ret_read, char *buffer);
#endif
